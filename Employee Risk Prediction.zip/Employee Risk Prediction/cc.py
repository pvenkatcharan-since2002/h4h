def calc(age,dept,dist,education,edufield,years):
     
    return [[10,90]]